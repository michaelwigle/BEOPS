#include "StdAfx.h"
#include "frmDaily.h"

