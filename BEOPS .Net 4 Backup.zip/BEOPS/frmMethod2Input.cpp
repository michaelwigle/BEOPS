#include "StdAfx.h"
#include "frmMethod2Input.h"

