#include "StdAfx.h"
#include "frmMethod1Input.h"

